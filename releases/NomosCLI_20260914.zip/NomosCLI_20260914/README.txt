Nomos CLI
=========

Запуск (Python не нужен):

    NomosCLI.exe                       обычный прогон
    NomosCLI.exe --help                все параметры
    NomosCLI.exe mode=Assets_filters time_delta_hours=168

Перед первым запуском заполните доступ к MaxPatrol:
скопируйте configs\example.config.env в configs\.config.env
и впишите MPX_HOST и токен.

Папка configs\ должна лежать рядом с исполняемым файлом.
Отчёты появятся в out\, журналы — в logs\, там же рядом.

Отладка:
    NomosCLI.exe dump_queries=true     план предстоящих запросов
    NomosCLI.exe debug_dump=true       сырые ответы API в debug\
    NomosCLI.exe logging_level=DEBUG   трассировка HTTP

Собрано: 2026-09-14 14:56
